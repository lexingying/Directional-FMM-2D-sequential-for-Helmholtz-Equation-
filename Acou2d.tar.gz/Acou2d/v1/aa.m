if(1)
  % create geometry and data
  K = 1024;
  H = K/2;
  NPW = 16;
  N = ceil(2*pi*H*NPW);
  
  ctr = [0;0];
  accu = 1; %1-3
  kt = 4; %0=SL, 1=DL, 2=CL, 3=DX1, 4=DX2
  numchk = 20;
  
  theta = [0:N-1]/N * 2*pi;
  R = 0.875*H;
  ps = [R*cos(theta); R*sin(theta)];
  ns = [cos(theta); sin(theta)];
  
  tic; ptr = FMM_setup(ps,ns,ctr,accu,kt); toc;
  for g=1:2
    fs = randn(N,1) + i*randn(N,1);
    tic; us = FMM_eval(ptr,fs); toc;
    relerr = FMM_check(ptr,fs,us,numchk);
    fprintf(1, '%d\n', relerr);
  end
  FMM_destroy(ptr);
end


