#include "mex.h"
#include "mexaux.hpp"

using namespace std;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  //input
  DblNumMat ps;  mex2cpp(prhs[0], ps);
  DblNumMat ns;  mex2cpp(prhs[1], ns);
  DblNumVec cc;  mex2cpp(prhs[2], cc);
  int accu; mex2cpp(prhs[3], accu);
  int knlbietp; mex2cpp(prhs[4], knlbietp);
  vector<Point2> posvec(ps.n());
  for(int i=0; i<posvec.size(); i++)    posvec[i] = Point2(ps(0,i), ps(1,i));
  vector<Point2> norvec(ns.n());
  for(int i=0; i<norvec.size(); i++)    norvec[i] = Point2(ns(0,i), ns(1,i));
  Point2 ctr(cc(0),cc(1));  
  
  //call setup
  Wave2d* ptr = new Wave2d("");
  iC( ptr->setup(posvec, norvec, ctr, accu, knlbietp) );
  
  //output
  cpp2mex(ptr, plhs[0]);
  return;
}
