#include "mex.h"
#include "mexaux.hpp"

using namespace std;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  //input
  Wave2d* ptr;  mex2cpp(prhs[0], ptr);
  CpxNumVec ds; mex2cpp(prhs[1], ds);
  vector<cpx> den(ds.m());  for(int i=0; i<den.size(); i++)    den[i] = ds(i);
  
  //call eval
  vector<cpx> val(den.size());
  iC( ptr->eval(den,val) );
  
  //output
  CpxNumVec vs(val.size());  for(int i=0; i<val.size(); i++)    vs(i) = val[i];
  cpp2mex(vs, plhs[0]);
  return;
}
