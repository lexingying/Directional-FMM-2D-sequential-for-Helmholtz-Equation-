#include "mex.h"
#include "mexaux.hpp"

using namespace std;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  //input
  Wave2d* ptr;  mex2cpp(prhs[0], ptr);
  
  //call eval
  delete ptr;
  
  //output
  return;
}
