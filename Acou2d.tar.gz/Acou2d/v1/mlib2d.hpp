#ifndef _MLIB2D_HPP_
#define _MLIB2D_HPP_

#include "comobject.hpp"
#include "vec2t.hpp"
#include "numtns.hpp"
#include "offtns.hpp"
#include "kernel2d.hpp"
#include "vecmatop.hpp"

using std::vector;
using std::pair;
using std::map;

class LowFreqEntry
{
public:
  DblNumMat _uep;
  DblNumMat _ucp;
  NumVec<CpxNumMat> _uc2ue;
  NumMat<CpxNumMat> _ue2dc;
public:
  LowFreqEntry() {;}
  ~LowFreqEntry() {;}
  DblNumMat& uep() { return _uep; }
  DblNumMat& ucp() { return _ucp; }
  NumVec<CpxNumMat>& uc2ue() { return _uc2ue; }
  NumMat<CpxNumMat>& ue2dc() { return _ue2dc; }
};

class HghFreqDirEntry
{
public:
  DblNumMat _uep;
  DblNumMat _ucp;
  NumVec<CpxNumMat> _uc2ue;
public:
  HghFreqDirEntry() {;}
  ~HghFreqDirEntry() {;}
  DblNumMat& uep() { return _uep; }
  DblNumMat& ucp() { return _ucp; }
  NumVec<CpxNumMat>& uc2ue() { return _uc2ue; }
};

//-----------------------------------
class Mlib2d: public ComObject
{
public:
  //PARAM required
  Kernel2d _knl;
  int _accu;
  //INTERNAL
  map<double, LowFreqEntry> _w2ldmap;
  map<double, map<Index2,HghFreqDirEntry> > _w2hdmap;
public:
  Mlib2d(const string& p);
  ~Mlib2d();
  //
  map<double, LowFreqEntry>& w2ldmap() { return _w2ldmap; }
  map<double, map<Index2, HghFreqDirEntry> >& w2hdmap() { return _w2hdmap; }
  //init
  int setup(Kernel2d knl, int accu);
  //use it
  int upward_lowfetch(double W, DblNumMat& uep, DblNumMat& ucp, NumVec<CpxNumMat>& uc2ue,
		      NumMat<CpxNumMat>& ue2uc);
  int dnward_lowfetch(double W, DblNumMat& dep, DblNumMat& dcp, NumVec<CpxNumMat>& dc2de,
		      NumMat<CpxNumMat>& de2dc, NumMat<CpxNumMat>& ue2dc, DblNumMat& uep);
  int upward_hghfetch(double W, Index2 dir, DblNumMat& uep, DblNumMat& ucp, NumVec<CpxNumMat>& uc2ue,
		      NumMat<CpxNumMat>& ue2uc);
  int dnward_hghfetch(double W, Index2 dir, DblNumMat& dep, DblNumMat& dcp, NumVec<CpxNumMat>& dc2de,
		      NumMat<CpxNumMat>& de2dc, DblNumMat& uep);
  int hghfetch_shuffle(Index2 prm, Index2 sgn, DblNumMat& tmp, DblNumMat& res);
  int hghfetch_index2sort(Index2 val, Index2& srt, Index2& sgn, Index2& prm);
  Index2 predir(Index2 dir);
};

//-------------------
int serialize(const LowFreqEntry&, ostream&, const vector<int>&);
int deserialize(LowFreqEntry&, istream&, const vector<int>&);
//-------------------
int serialize(const HghFreqDirEntry&, ostream&, const vector<int>&);
int deserialize(HghFreqDirEntry&, istream&, const vector<int>&);

#endif
