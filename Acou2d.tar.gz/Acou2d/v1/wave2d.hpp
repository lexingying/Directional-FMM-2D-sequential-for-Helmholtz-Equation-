#ifndef _WAVE2D_HPP_
#define _WAVE2D_HPP_

#include "comobject.hpp"
#include "vec2t.hpp"
#include "numtns.hpp"
#include "offtns.hpp"
#include "kernel2d.hpp"
#include "mlib2d.hpp"

using std::vector;
using std::pair;
using std::map;
using std::set;
using std::cerr;
using std::cout;
using std::ifstream;
using std::ofstream;

enum {
  WAVE2D_PTS = 1,
  WAVE2D_TERMINAL = 2,
};

//---------------------------------------------------------------------------
class Wave2d: public ComObject
{
public:
  //-----------------------
  typedef pair<int,Index2> BoxKey; //level, offset_in_level
  //-----------------------
  class BoxDat { //tree node
  public:
    int _tag;
    vector<int> _ptidxvec; //index of points in this node
    //low freq dat
    vector<BoxKey> _undeidxvec;
    vector<BoxKey> _vndeidxvec;
    vector<BoxKey> _wndeidxvec;
    vector<BoxKey> _xndeidxvec;
    vector<BoxKey> _endeidxvec;
    map< Index2, vector<BoxKey> > _fndeidxvec;
    DblNumMat _extpos;
    DblNumMat _extnor;
    CpxNumVec _extden;
    CpxNumVec _extval;
    CpxNumVec _upeqnden;
    CpxNumVec _dnchkval;
    //   aux dat
    set<Index2> _incdirset;
    set<Index2> _outdirset;
  public:
    BoxDat(): _tag(0) {;}
    //
    int& tag() { return _tag; }
    vector<int>& ptidxvec() { return _ptidxvec; }
    //
    vector<BoxKey>& undeidxvec() { return _undeidxvec; }
    vector<BoxKey>& vndeidxvec() { return _vndeidxvec; }
    vector<BoxKey>& wndeidxvec() { return _wndeidxvec; }
    vector<BoxKey>& xndeidxvec() { return _xndeidxvec; }
    vector<BoxKey>& endeidxvec() { return _endeidxvec; }
    map< Index2, vector<BoxKey> >& fndeidxvec() { return _fndeidxvec; } //LEXING: ordered using incoming direction
    DblNumMat& extpos() { return _extpos; }
    DblNumMat& extnor() { return _extnor; }
    CpxNumVec& extden() { return _extden; }
    CpxNumVec& extval() { return _extval; }
    CpxNumVec& upeqnden() { return _upeqnden; }
    CpxNumVec& dnchkval() { return _dnchkval; }
    set<Index2>& incdirset() { return _incdirset; }
    set<Index2>& outdirset() { return _outdirset; }
  };
  //-----------------------
  typedef pair<BoxKey,Index2> BndKey;
  //-----------------------
  class BndDat{
  public:
    CpxNumVec _dirupeqnden;
    CpxNumVec _dirdnchkval;
  public:
    BndDat() {;}
    ~BndDat() {;}
    CpxNumVec& dirupeqnden() { return _dirupeqnden; }
    CpxNumVec& dirdnchkval() { return _dirdnchkval; }
  };
  //-----------------------
public:
  vector<Point2> _posvec; //
  vector<Point2> _norvec; //normal directions
  Point2 _ctr; //the center of the toplevel box
  int _accu;
  Kernel2d _knlbie; //kernel used in the integral equation
  // internal data
  double _K; //max frequency, typically 32, 64, 128, 256, also the width of the largest box
  int _ptsmax; //max number of pts in the leaf nodes
  int _maxlevel; //the maximum number of levels allowed in the tree
  Mlib2d _mlib;
  map<BoxKey,BoxDat> _boxvec;
  map<BndKey,BndDat> _bndvec;
  //
  static Wave2d* _self;
  //
  CpxNumMat _direct;
public:
  Wave2d(const string& p);
  ~Wave2d();
  double width() { return _K; }  //double minwidth() { return _ndevec[_ndevec.size()-1].width(); }
  //
  Point2 center(BoxKey& curkey) {
    int depth = curkey.first;
    Index2 path = curkey.second;
    int tmp = pow2(depth);
    Point2 t;	for(int d=0; d<2; d++)	  t(d) = _ctr(d) - _K/2 + (path(d)+0.5)/tmp*_K;
    return t;
  }
  double width(BoxKey& curkey) {
    int depth = curkey.first;
    int tmp = pow2(depth);
    return _K/tmp;
  }
  //bool iscell(const BoxKey& curkey) {    return (curkey.first==celllevel());  }
  bool isroot(const BoxKey& curkey) { return (curkey.first==0); }
  BoxKey parkey(BoxKey& curkey) {
    BoxKey tmp;	tmp.first = curkey.first-1;	tmp.second = curkey.second/2;
    return tmp;
  }
  BoxKey chdkey(BoxKey& curkey, Index2 idx) {
    BoxKey tmp;	tmp.first = curkey.first + 1;	tmp.second = 2*curkey.second + idx;
    return tmp;
  }
  BoxDat& boxdat(BoxKey& curkey) {
    map<BoxKey,BoxDat>::iterator mi = _boxvec.find(curkey);    iA(mi!=_boxvec.end());
    return (*mi).second;
  }
  bool isterminal(BoxDat& curdat) {
    return (curdat.tag()&WAVE2D_TERMINAL);
  }
  bool ispts(BoxDat& curdat) {
    return (curdat.tag()&WAVE2D_PTS);
  }
  int dim() { return 2; }
  //int nlevels() { return _ndevec[_ndevec.size()-1].level()+1; } //TOTOL NUMBER OF LEVELS
  int unitlevel() { return int(round(log(_K)/log(2))); } //the level such that the box has width 1
  Index2 nml2dir(Point2 nml, double W);
  Index2 predir(Index2 dir);
  vector<Index2> chddir(Index2 dir);
  double dir2width(Index2 dir);
  //
  int setup(vector<Point2>& posvec, vector<Point2>& norvec, Point2 ctr, int accu, int knlbietp);
  int setup_tree();
  int setup_tree_callowlist( BoxKey, BoxDat& );
  int setup_tree_calhghlist( BoxKey, BoxDat& );
  bool setup_tree_find(BoxKey wntkey, BoxKey& reskey);
  bool setup_tree_adjacent(BoxKey me, BoxKey yo);
  //
  int eval(vector<cpx>& den, vector<cpx>& val);
  int eval_upward_low(double W, vector<BoxKey>&); //may be we can make it to be local index
  int eval_dnward_low(double W, vector<BoxKey>&);
  int eval_upward_hgh_recursive(double W, Index2 nowdir, map< Index2, pair< vector<BoxKey>, vector<BoxKey> > >& hdmap);
  int eval_dnward_hgh_recursive(double W, Index2 nowdir, map< Index2, pair< vector<BoxKey>, vector<BoxKey> > >& hdmap);
  int eval_upward_hgh(double W, Index2 dir, pair< vector<BoxKey>, vector<BoxKey> >& hdvecs);
  int eval_dnward_hgh(double W, Index2 dir, pair< vector<BoxKey>, vector<BoxKey> >& hdvecs);
  //
  int check(vector<cpx>& den, vector<cpx>& val, int numchk, double& relerr);
  //--------------
  //int setup_direct(vector<Point2>& posvec, vector<Point2>& norvec, Point2 ctr, int accu, Kernel2d knlbie);
  //int eval_direct(vector<cpx>& den, vector<cpx>& val);
  /*
    int bf_upordercollect(vector<int>&);
    int bf_dnordercollect(vector<int>&);
    int df_upordercollect(vector<int>&);
    int df_upordercollect_aux(int, vector<int>&);
    int df_dnordercollect(vector<int>&);
    int df_dnordercollect_aux(int, vector<int>&);
  */
};

#endif

