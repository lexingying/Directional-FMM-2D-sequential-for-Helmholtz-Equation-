#include "kernel2d.hpp"

double Kernel2d::_mindif = 1e-8;
using std::polar;
using std::cerr;

extern "C"
{
  void vdsqrt_(int* n, double*, double*);
  void vdinv_(int* n, double*, double*);
  void vdsincos_(int* n, double*, double*, double*);
}

//---------------------------------------------------------------------------
int Kernel2d::kernel(const DblNumMat& trgpos, const DblNumMat& srcpos, const DblNumMat& srcnor, CpxNumMat& inter)
{
  int sdof = this->sdof();
  int tdof = this->tdof();
  cpx I(0,1);
  double mindif2 = _mindif*_mindif;
  int M = trgpos.n();
  int N = srcpos.n();
  int TTL = M*N;
  cpx coef = 0.25 * I;
  inter.resize(trgpos.n(), srcpos.n());  //clear(inter);
  //-----------------------------------------
  if(       _type==KNL_HELM_SING) {
    double K = 2*M_PI; //LEXING: SPECIAL
    for(int i=0; i<trgpos.n(); i++) {
      for(int j=0; j<srcpos.n(); j++) {
	double r0 = trgpos(0,i) - srcpos(0,j);	  double r1 = trgpos(1,i) - srcpos(1,j);
	double rr = r0*r0 + r1*r1;
	double r = sqrt(rr);
	if(r<_mindif) {
	  inter(i,j) = 0;
	} else {
	  double Kr = K*r;
	  inter(i,j) = cpx( -0.25*y0(Kr), 0.25*j0(Kr) );
	  //inter(i,j) =  0.25 * I * cpx(j0(Kr), y0(Kr));
	}
      }
    }
  } else if(_type==KNL_HELM_DOUB) {
    double K = 2*M_PI;
    for(int i=0; i<trgpos.n(); i++) {
      for(int j=0; j<srcpos.n(); j++) {
	double r0 = trgpos(0,i) - srcpos(0,j);	  double r1 = trgpos(1,i) - srcpos(1,j);
	double n0 = srcnor(0,j);	double n1 = srcnor(1,j);
	double rr = r0*r0 + r1*r1;
	double rn = r0*n0 + r1*n1;
	double r = sqrt(rr);
	if(r<_mindif) {
	  inter(i,j) = 0;
	} else {
	  double Kr = K*r;
	  inter(i,j) = I/4.0 * K * cpx(j1(Kr),y1(Kr)) * rn / r;
	}
      }
    }
  } else if(_type==KNL_HELM_COMB) {
    double K = 2*M_PI;
    double eta = M_PI;
    for(int i=0; i<trgpos.n(); i++) {
      for(int j=0; j<srcpos.n(); j++) {
	double r0 = trgpos(0,i) - srcpos(0,j);	  double r1 = trgpos(1,i) - srcpos(1,j);
	double n0 = srcnor(0,j);	double n1 = srcnor(1,j);
	double rr = r0*r0 + r1*r1;
	double rn = r0*n0 + r1*n1;
	double r = sqrt(rr);
	if(r<_mindif) {
	  inter(i,j) = 0;
	} else {
	  double Kr = K*r;
	  //inter(i,j) = I/4.0 * K * cpx(j1(Kr),y1(Kr)) * rn / r - I* eta * I/4.0 * cpx(j0(Kr),y0(Kr));
	  inter(i,j) = I/4.0 * K * cpx(j1(Kr),y1(Kr)) * rn / r + eta/4.0 * cpx(j0(Kr),y0(Kr));
	}
      }
    }
  } else if(_type==KNL_HELM_DX1) {
    double K = 2*M_PI;
    for(int i=0; i<trgpos.n(); i++) {
      for(int j=0; j<srcpos.n(); j++) {
	double r0 = trgpos(0,i) - srcpos(0,j);	  double r1 = trgpos(1,i) - srcpos(1,j);
	//double n0 = srcnor(0,j);	double n1 = srcnor(1,j);
	double rr = r0*r0 + r1*r1;
	//double rn = r0*n0 + r1*n1;
	double r = sqrt(rr);
	if(r<_mindif) {
	  inter(i,j) = 0;
	} else {
	  double Kr = K*r;
	  inter(i,j) = -I/4.0 * K * cpx(j1(Kr),y1(Kr)) * r0 / r;
	}
      }
    }
  } else if(_type==KNL_HELM_DX2) {
    double K = 2*M_PI;
    for(int i=0; i<trgpos.n(); i++) {
      for(int j=0; j<srcpos.n(); j++) {
	double r0 = trgpos(0,i) - srcpos(0,j);	  double r1 = trgpos(1,i) - srcpos(1,j);
	//double n0 = srcnor(0,j);	double n1 = srcnor(1,j);
	double rr = r0*r0 + r1*r1;
	//double rn = r0*n0 + r1*n1;
	double r = sqrt(rr);
	if(r<_mindif) {
	  inter(i,j) = 0;
	} else {
	  double Kr = K*r;
	  inter(i,j) = -I/4.0 * K * cpx(j1(Kr),y1(Kr)) * r1 / r;
	}
      }
    }
  } else if(_type==KNL_EXPR) {
    /*
    //-------------------------------
    double K = M_PI; //LEXING: SPECIAL
    DblNumMat rr(M,N);
    for(int i=0; i<M; i++) {
    for(int j=0; j<N; j++) {
    double r1 = trgpos(0,i) - srcpos(0,j);	  double r2 = trgpos(1,i) - srcpos(1,j);
    double tmp = r1*r1 + r2*r2;
    rr(i,j) = tmp;
    if(tmp<mindif2)
    rr(i,j) = 1;
    }
    }
    DblNumMat r(M,N);
    vdsqrt_(&TTL, rr.data(), r.data());
    DblNumMat& kr = r; //Kr
    for(int i=0; i<M; i++)	for(int j=0; j<N; j++)	  kr(i,j) *= K;
    DblNumMat skr(M,N), ckr(M,N);
    vdsincos_(&TTL, kr.data(), skr.data(), ckr.data());
    inter.resize(M,N);
    for(int i=0; i<M; i++)	for(int j=0; j<N; j++)	  inter(i,j) = cpx( ckr(i,j), skr(i,j) );
    */
  } else {
    //-------------------------------
    iA(0);
  }
  return 0;
}

