#include "wave2d.hpp"

using std::cerr;

Wave2d* Wave2d::_self = NULL;

//-----------------------------------
Wave2d::Wave2d(const string& p): ComObject(p), _mlib(p+"_mlib")
{
  _self = this;
}

//-----------------------------------
Wave2d::~Wave2d()
{
  _self = this;
}

//-----------------------------------
Index2 Wave2d::nml2dir(Point2 n, double W)
{
  int NPQ = 2;
  int C = NPQ * int(round(W));
  int B = C/2;
  int midx = 0;  double mval = abs(n(0));
  for(int d=1; d<2; d++)
    if(mval<abs(n(d))) {
      midx = d;	  mval = abs(n(d));
    }
  //val gives the direction (can be + or -)
  Point2 val = n / mval;
  for(int d=0; d<2; d++)	val(d) = atan(val(d));
  double Ang = (M_PI/2)/C;
  Index2 res;
  for(int d=0; d<2; d++) {
    int tmp = int(floor(val(d)/Ang));
    tmp = min(max(tmp,-B), B-1);
    res(d) = 2*tmp + 1;
  }
  res(midx) = C*int(round(val(midx))); //val(midx)==1 or -1
  return res;
}

//-----------------------------------
Index2 Wave2d::predir(Index2 dir)
{
  int C = dir.linfty();
  int B = C/2;
  int midx = -1;
  for(int d=0; d<2; d++)	if(abs(dir(d))==C) midx = d;
  assert(midx!=-1);
  //midx gives the direction
  Index2 res;
  for(int d=0; d<2; d++)	res(d) = (dir(d) + C - 1) / 2;
  for(int d=0; d<2; d++)	res(d) = 2*(res(d)/2) + 1 - B;
  res(midx) = dir(midx) / 2;
  return res;
}

//-----------------------------------
vector<Index2> Wave2d::chddir(Index2 dir)
{
  int C = dir.linfty();
  int midx = -1;
  vector<int> oidx;
  for(int d=0; d<2; d++)
    if(abs(dir(d))==C)
      midx = d;
    else
      oidx.push_back(d);
  assert(midx!=-1);  assert(oidx.size()==1);
  vector<Index2> res;
  for(int a=0; a<2; a++) {
    Index2 tmp = 2*dir;
    tmp(oidx[0]) += 2*a-1;
    res.push_back(tmp);
  }
  return res;
}

//-----------------------------------
double Wave2d::dir2width(Index2 dir)
{
  int NPQ = 2;
  int C = dir.linfty();
  return double(C/NPQ);
}
