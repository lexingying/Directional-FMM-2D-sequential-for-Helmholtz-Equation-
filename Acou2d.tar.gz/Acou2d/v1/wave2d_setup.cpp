#include "wave2d.hpp"

using std::istringstream;
using std::ifstream;
using std::ofstream;
using std::set;
using std::queue;
using std::cerr;

//---------------------------------------------------------------------
int Wave2d::setup(vector<Point2>& posvec, vector<Point2>& norvec, Point2 ctr, int accu, int knlbietp)
{
  _self = this;
  _posvec = posvec;
  _norvec = norvec;
  _ctr = ctr;
  _accu = accu;
  _knlbie = Kernel2d(knlbietp); //create kernel
  //mlib
  iA(_knlbie.type()==KNL_HELM_SING ||
     _knlbie.type()==KNL_HELM_DOUB ||
     _knlbie.type()==KNL_HELM_COMB ||
     _knlbie.type()==KNL_HELM_DX1 ||
     _knlbie.type()==KNL_HELM_DX2
     );
  iC( _mlib.setup( Kernel2d(KNL_HELM_SING), _accu) );
  //figure out the following
  double dist = 0;
  for(int k=0; k<_posvec.size(); k++) {
    Point2 p = posvec[k];
    //dist = max( dist, max(p(0)-_ctr(0),p(1)-_ctr(1)) );
    dist = max(dist, (p-_ctr).linfty());
  }
  dist = dist*2; //get diameter
  int tmp = max(0, (int)ceil(log(dist)/log(2)));
  _K = pow2(tmp); cerr<<"K "<<_K<<endl; //LEXING
  _ptsmax = 10;
  _maxlevel = 16;
  //generate the tree, _ndevec
  _boxvec.clear();
  _bndvec.clear();
  iC( setup_tree() );
  return 0;
}

//---------------------------------------------------------------------
int Wave2d::setup_tree()
{
  double eps = 1e-12;
  int sdof = 1;
  int tdof = 1;
  double R = width()/2.0;
  Point2 bbmin( _ctr-Point2(R,R) );
  Point2 bbmax( _ctr+Point2(R,R) );
  BoxDat curdat;
  for(int k=0; k<_posvec.size(); k++) {
    Point2 tmp = _posvec[k];
    iA( (tmp[0]>=bbmin[0] && tmp[1]>=bbmin[1]) &&
	(tmp[0]<=bbmax[0] && tmp[1]<=bbmax[1]) ); //IMPORTANT
    curdat.ptidxvec().push_back(k);
  }
  queue< pair<BoxKey,BoxDat> > tmpq;
  BoxKey curkey;
  curkey.first = 0;  curkey.second = Index2(0,0);
  tmpq.push( pair<BoxKey,BoxDat>(curkey,curdat) );
  //--- tree
  while(tmpq.empty()==false) {
    pair<BoxKey,BoxDat> curent = tmpq.front();	tmpq.pop();
    BoxKey& curkey = curent.first;
    BoxDat& curdat = curent.second;
    //LEXING: VERY IMPORTANT
    if(curdat.ptidxvec().size()>0)
      curdat.tag() = curdat.tag() | WAVE2D_PTS;
    bool action = (curkey.first<=unitlevel() && curdat.ptidxvec().size()>0) ||
      (curdat.ptidxvec().size()>_ptsmax && curkey.first<_maxlevel-1);
    if(action) {
      //1. subdivide to get new children
      NumMat<BoxDat> chdboxmat(2,2);
      Point2 curctr = center(curkey); //LEXING: VERY IMPORTANT
      for(int g=0; g<curdat.ptidxvec().size(); g++) {
	int tmpidx = curdat.ptidxvec()[g];
	Point2 tmp = _posvec[tmpidx];
	Index2 idx;
	for(int d=0; d<2; d++)		  idx(d) = (tmp(d)>=curctr(d));
	chdboxmat(idx(0),idx(1)).ptidxvec().push_back(tmpidx); //put points to children
      }
      //2. put non-empty ones into queue
      for(int a=0; a<2; a++)
	for(int b=0; b<2; b++) {
	  BoxKey chdkey = this->chdkey(curkey, Index2(a,b));
	  tmpq.push( pair<BoxKey,BoxDat>(chdkey, chdboxmat(a,b)) );
	}
      //4. clear my own ptidxvec vector
      curdat.ptidxvec().clear();
    } else {
      //1. copy data into _extpos
      curdat.extpos().resize(2,curdat.ptidxvec().size());
      curdat.extnor().resize(2,curdat.ptidxvec().size());
      for(int g=0; g<curdat.ptidxvec().size(); g++) {
	int tmpidx = curdat.ptidxvec()[g];
	Point2 tmppos = _posvec[tmpidx];
	for(int d=0; d<2; d++)	  curdat.extpos()(d,g) = tmppos(d);
	Point2 tmpnor = _norvec[tmpidx];
	for(int d=0; d<2; d++)	  curdat.extnor()(d,g) = tmpnor(d);
      }
      //LEXING: VERY IMPORTANT
      curdat.tag() = curdat.tag() | WAVE2D_TERMINAL;
    }
    //add my self into _tree
    _boxvec[curkey] = curdat;    //_boxvec.insert(curkey, curdat); //LEXING: CHECK
  }
  //cerr<<"setup_tree, done tree"<<endl;
  //compute lists (top down)
  for(map<BoxKey,BoxDat>::iterator mi=_boxvec.begin(); mi!=_boxvec.end(); mi++) {
    BoxKey curkey = (*mi).first;
    BoxDat& curdat = (*mi).second;
    if(curdat.tag()&WAVE2D_PTS) { //LEXING: JUST COMPUTE MY OWN BOXES
      if(width(curkey)<1-eps) { //LEXING: STRICTLY < 1
	iC( setup_tree_callowlist(curkey, curdat) );
      } else {
	iC( setup_tree_calhghlist(curkey, curdat) );
      }
    }
  }
  //cerr<<"setup_tree, done lists"<<endl;
  //preset high freq data in each node
  for(map<BoxKey,BoxDat>::iterator mi=_boxvec.begin(); mi!=_boxvec.end(); mi++) {
    BoxKey curkey = (*mi).first;
    BoxDat& curdat = (*mi).second;
    double W = width(curkey);
    if(W>1-eps && (curdat.tag()&WAVE2D_PTS)) {
      if(isroot(curkey)==false) {
	BoxKey parkey = this->parkey(curkey);
	BoxDat& pardat = _boxvec[parkey]; //LEXING: CHECK
	for(set<Index2>::iterator si=pardat.outdirset().begin(); si!=pardat.outdirset().end(); si++) {
	  Index2 nowdir = predir(*si);
	  curdat.outdirset().insert(nowdir);
	}
	for(set<Index2>::iterator si=pardat.incdirset().begin(); si!=pardat.incdirset().end(); si++) {
	  Index2 nowdir = predir(*si);
	  curdat.incdirset().insert(nowdir);
	}
      }
      //go thrw
      Point2 curctr = center(curkey);
      for(map< Index2,vector<BoxKey> >::iterator mi=curdat.fndeidxvec().begin(); mi!=curdat.fndeidxvec().end(); mi++) {
	vector<BoxKey>& tmplist = (*mi).second;
	for(int k=0; k<tmplist.size(); k++) {
	  BoxKey othkey = tmplist[k];
	  //BoxDat& othdat = _boxvec.access(othkey);
	  Point2 othctr = center(othkey);
	  Point2 tmp;
	  if(othkey>curkey)
	    tmp = othctr-curctr;
	  else
	    tmp = -(curctr-othctr);
	  tmp = tmp/tmp.l2();
	  Index2 dir = nml2dir(tmp, W);
	  curdat.outdirset().insert(dir);
	  if(curkey>othkey)
	    tmp = curctr-othctr;
	  else
	    tmp = -(othctr-curctr);
	  tmp = tmp/tmp.l2();
	  dir = nml2dir(tmp, W);
	  curdat.incdirset().insert(dir);
	}
      }
    }
  }
  //cerr<<"setup_tree, done low, high data"<<endl;
  return 0;
}


//---------------------------------------------------------------------
int Wave2d::setup_tree_callowlist(BoxKey curkey, BoxDat& curdat)
{
  set<BoxKey> Uset, Vset, Wset, Xset;
  //const BoxKey& curkey = curent.first;
  //const BoxDat& curdat = curent.second;
  iA(isroot(curkey)==false); //LEXING: DO NOT ALLOW WIDTH=1 BOXES TO BE CELLS
  Index2 curpth = curkey.second;
  BoxKey parkey = this->parkey(curkey); //the link to parent
  Index2 parpth = parkey.second;
  //
  int L = pow2(curkey.first);  //Index2 minpth(0,0,0);  //Index2 maxpth(L,L,L);
  int il, iu, jl,ju;
  il = max(2*parpth(0)-2,0);	iu = min(2*parpth(0)+4,L);
  jl = max(2*parpth(1)-2,0);	ju = min(2*parpth(1)+4,L);
  for(int i=il; i<iu; i++)
    for(int j=jl; j<ju; j++) {
      Index2 trypth(i,j);
      if( (trypth(0)==curpth(0) && trypth(1)==curpth(1))==false ) {
	BoxKey wntkey(curkey.first, trypth);
	//LEXING: LOOK FOR IT, DO NOT EXIST IF NO CELL BOX COVERING IT
	BoxKey reskey;
	bool found = setup_tree_find(wntkey, reskey);
	BoxDat& resdat = _boxvec[reskey]; //LEXING: CHECK
	if(found) {
	  bool adj = setup_tree_adjacent(reskey, curkey);
	  if( reskey.first<curkey.first ) {
	    if(adj) {
	      if(isterminal(curdat)) {
		if(resdat.tag()&WAVE2D_PTS)
		  Uset.insert(reskey);
	      }
	    } else {
	      if(resdat.tag()&WAVE2D_PTS)
		Xset.insert(reskey);
	    }
	  }
	  if( reskey.first==curkey.first ) {
	    if(!adj) {
	      Index2 bb = reskey.second - curkey.second;				iA( bb.linfty()<=3 );
	      if(resdat.tag()&WAVE2D_PTS)
		Vset.insert(reskey);
	    } else {
	      if(isterminal(curdat)) {
		queue<BoxKey> rest;
		rest.push(reskey);
		while(rest.empty()==false) {
		  BoxKey fntkey = rest.front(); rest.pop();
		  BoxDat& fntdat = _boxvec[fntkey]; //LEXING: CHECK
		  if(setup_tree_adjacent(fntkey, curkey)==false) {
		    if(fntdat.tag()&WAVE2D_PTS)
		      Wset.insert(fntkey);
		  } else {
		    if(isterminal(fntdat)) {
		      if(fntdat.tag()&WAVE2D_PTS)
			Uset.insert(fntkey);
		    } else {
		      for(int a=0; a<2; a++)
			for(int b=0; b<2; b++)
			  rest.push( chdkey(fntkey, Index2(a,b)) );
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    }
  if(isterminal(curdat))
    if(curdat.tag()&WAVE2D_PTS)
      Uset.insert(curkey);
  //
  for(set<BoxKey>::iterator si=Uset.begin(); si!=Uset.end(); si++)
    curdat.undeidxvec().push_back(*si);
  for(set<BoxKey>::iterator si=Vset.begin(); si!=Vset.end(); si++)
	curdat.vndeidxvec().push_back(*si);
  for(set<BoxKey>::iterator si=Wset.begin(); si!=Wset.end(); si++)
	curdat.wndeidxvec().push_back(*si);
  for(set<BoxKey>::iterator si=Xset.begin(); si!=Xset.end(); si++)
	curdat.xndeidxvec().push_back(*si);
  return 0;
}

//---------------------------------------------------------------------
int Wave2d::setup_tree_calhghlist(BoxKey curkey, BoxDat& curdat)
{
  int NPQ = 2;
  Point2 curctr = center(curkey);
  double W = width(curkey);
  int C = NPQ*int(round(W));
  double eps = 1e-12;
  double D = W*W + W;
  if(isroot(curkey)==true) {
    curdat.endeidxvec().push_back(curkey);
  } else {
    BoxKey parkey = this->parkey(curkey);
    BoxDat& pardata = _boxvec[parkey]; //LEXING: CHECK
    for(int k=0; k<pardata.endeidxvec().size(); k++) {
      BoxKey trykey = pardata.endeidxvec()[k];
      BoxDat& trydata = _boxvec[trykey]; //LEXING: CHECK
      for(int a=0; a<2; a++)
	for(int b=0; b<2; b++) {
	  BoxKey othkey = chdkey(trykey, Index2(a,b));
	  BoxDat& othdat = _boxvec[othkey]; //LEXING: CHECK
	  if(othdat.tag() & WAVE2D_PTS) {
	    //LEXING: ALWAYS target - source
	    Point2 diff;
	    if(curkey>othkey)
	      diff = curctr-center(othkey);
	    else
	      diff = -(center(othkey)-curctr);
	    if(diff.l2()>=D-eps) {
	      Index2 dir = nml2dir(diff/diff.l2(), W);
	      curdat.fndeidxvec()[dir].push_back(othkey);
	    } else {
	      curdat.endeidxvec().push_back(othkey);
	    }
	  }
	}
    }
  }
  return 0;
}

// ----------------------------------------------------------------------
bool Wave2d::setup_tree_find(BoxKey wntkey, BoxKey& trykey)
{
  trykey = wntkey;
  while(isroot(trykey)==false) {
    map<BoxKey,BoxDat>::iterator mi=_boxvec.find(trykey);
    if(mi!=_boxvec.end())
      return true; //found
    trykey = parkey(trykey);
  }
  map<BoxKey,BoxDat>::iterator mi=_boxvec.find(trykey);
  return (mi!=_boxvec.end());
}

// ----------------------------------------------------------------------
bool Wave2d::setup_tree_adjacent(BoxKey meekey, BoxKey youkey)
{
  int md = max(meekey.first,youkey.first);
  Index2 one(1,1);
  Index2 meectr(  (2*meekey.second+one) * pow2(md - meekey.first)  );
  Index2 youctr(  (2*youkey.second+one) * pow2(md - youkey.first)  );
  int meerad = pow2(md - meekey.first);
  int yourad = pow2(md - youkey.first);
  Index2 dif( ewabs(meectr-youctr) );
  int rad  = meerad + yourad;
  return
    (dif[0]<=rad && dif[1]<=rad) &&
    ( dif.linfty() == rad ); //at least one edge touch
}






