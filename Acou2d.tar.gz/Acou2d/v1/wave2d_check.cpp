#include "wave2d.hpp"
#include "vecmatop.hpp"

using std::ofstream;

//---------------------------------------------------------------------
int Wave2d::check(vector<cpx>& den, vector<cpx>& val, int numchk, double& relerr)
{
  _self = this;
  //LY: CHECK
  int dim = this->dim();
  int sdof = 1;
  int tdof = 1;
  int pnum = _posvec.size();
  DblNumMat allpos(dim,pnum);
  DblNumMat allnor(dim,pnum);
  for(int k=0; k<pnum; k++)
    for(int i=0; i<dim; i++) {
      allpos(i,k) = _posvec[k](i);      allnor(i,k) = _norvec[k](i);
    }
  //1. select point to check
  vector<int> chkvec(numchk);
  for(int k=0; k<numchk; k++) {
    chkvec[k] = int( floor(drand48()*pnum) );	 iA(chkvec[k]>=0 && chkvec[k]<pnum);
  }
  DblNumMat chkpos(dim, numchk);
  CpxNumVec chkval(numchk*tdof);
  CpxNumVec chkdns(numchk*tdof);
  for(int k=0; k<numchk; k++) {
    for(int i=0; i<dim; i++)		chkpos(i, k) = allpos(i, chkvec[k]);
    for(int i=0; i<tdof;i++)		chkval(k*tdof+i) = val[ chkvec[k]*tdof+i ];
  }
  //2. compute
  CpxNumMat inter(tdof, pnum*sdof);
  CpxNumVec denvec(pnum,false,&(den[0]));
  for(int k=0; k<numchk; k++) {
    DblNumMat onechkpos(dim, 1, false, chkpos.clmdata(k));
    CpxNumVec onechkdns(tdof, false, chkdns.data()+k*tdof);
    iC( _knlbie.kernel(onechkpos, allpos, allnor, inter) );
    iC( zgemv(1.0, inter, denvec, 0.0, onechkdns) );
  }
  //3. error
  CpxNumVec chkerr(numchk*tdof);
  for(int k=0; k<numchk; k++)
    for(int i=0; i<tdof; i++)
      chkerr(k*tdof+i) = chkval(k*tdof+i)-chkdns(k*tdof+i);
  double dn = 0;  double en = 0;
  for(int k=0; k<numchk; k++)
	for(int i=0; i<tdof; i++) {
	  dn += abs(chkdns(k*tdof+i))*abs(chkdns(k*tdof+i));
	  en += abs(chkerr(k*tdof+i))*abs(chkerr(k*tdof+i));
	}
  dn = sqrt(dn);
  en = sqrt(en);
  relerr = en/dn;
  return 0;
}

