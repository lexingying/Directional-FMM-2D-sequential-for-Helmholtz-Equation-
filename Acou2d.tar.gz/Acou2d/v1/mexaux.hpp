#ifndef _MEXAUX_HPP_
#define _MEXAUX_HPP_

#include "mex.h"
#include "matrix.h"

#include "wave2d.hpp"

inline void mex2cpp(const mxArray*& md, int& cd);
inline void cpp2mex(const int& cd, mxArray*& md);

inline void mex2cpp(const mxArray*& md, double& cd);
inline void cpp2mex(const double& cd, mxArray*& md);

inline void mex2cpp(const mxArray*& md, DblNumMat& cd);
inline void cpp2mex(const DblNumMat& cd, mxArray*& md);

inline void mex2cpp(const mxArray*& md, DblNumVec& cd);
inline void cpp2mex(const DblNumVec& cd, mxArray*& md);

inline void mex2cpp(const mxArray*& md, CpxNumVec& cd);
inline void cpp2mex(const CpxNumVec& cd, mxArray*& md);

inline void mex2cpp(const mxArray*& md, Wave2d*& ptr);
inline void cpp2mex(Wave2d*& cd, mxArray*& md);

//----------------------ptr
inline void mex2cpp(const mxArray*& md, Wave2d*& ptr)
{
  ptr = *((Wave2d**)(mxGetPr(md)));
  return;
}
inline void cpp2mex(Wave2d*& ptr, mxArray*& md)
{
  md = mxCreateNumericMatrix(1, 1, mxUINT32_CLASS, mxREAL);
  *((Wave2d**)(mxGetPr(md))) = ptr;
  return;
}

//----------------------int
inline void mex2cpp(const mxArray*& md, int& cd)
{
  cd = int(mxGetScalar(md));
  return;
}
inline void cpp2mex(const int& cd, mxArray*& md)
{
  md = mxCreateDoubleScalar(cd);
  return;
}

//----------------------double
inline void mex2cpp(const mxArray*& md, double& cd)
{
  cd = mxGetScalar(md);
  return;
}
inline void cpp2mex(const double& cd, mxArray*& md)
{
  md = mxCreateDoubleScalar(cd);
  return;
}

//----------------------dblnummat
inline void mex2cpp(const mxArray*& md, DblNumMat& cd)
{
  int m = mxGetM(md);
  int n = mxGetN(md);
  double* xr = mxGetPr(md);
  double* xi = mxGetPi(md);
  cd.resize(m,n);
  if(xr!=NULL) {
	int cnt = 0;
	for(int j=0; j<n; j++)
	  for(int i=0; i<m; i++) {
		cd(i,j) = xr[cnt];
		cnt++;
	  }
  }
  return;
}
inline void cpp2mex(const DblNumMat& cd, mxArray*& md)
{
  int m = cd.m();
  int n = cd.n();
  md = mxCreateDoubleMatrix(m, n, mxREAL);
  double* xr = mxGetPr(md);
  int cnt = 0;
  for(int j=0; j<n; j++)
	for(int i=0; i<m; i++) {
	  xr[cnt] = cd(i,j);
	  cnt++;
	}
  return;
}

//----------------------DblNumVec
inline void mex2cpp(const mxArray*& md, DblNumVec& cd)
{
  int m = mxGetM(md);
  int n = mxGetN(md);  iA(n==1);
  double* xr = mxGetPr(md);
  cd.resize(m);
  if(xr!=NULL) {
    for(int i=0; i<m; i++) {
      cd(i) = xr[i];
    }
  }
  return;
}
inline void cpp2mex(const DblNumVec& cd, mxArray*& md)
{
  int m = cd.m();
  md = mxCreateDoubleMatrix(m, 1, mxREAL);
  double* xr = mxGetPr(md);
  for(int i=0; i<m; i++) {
    xr[i] = cd(i);
  }
  return;
}

//----------------------cpxnumvec
inline void mex2cpp(const mxArray*& md, CpxNumVec& cd)
{
  int m = mxGetM(md);
  int n = mxGetN(md);  iA(n==1);
  double* xr = mxGetPr(md);
  double* xi = mxGetPi(md);
  cd.resize(m);
  if(xr!=NULL && xi!=NULL) {
	for(int i=0; i<m; i++) {
	  cd(i) = cpx(xr[i], xi[i]);
	}
  }
  return;
}
inline void cpp2mex(const CpxNumVec& cd, mxArray*& md)
{
  int m = cd.m();
  md = mxCreateDoubleMatrix(m, 1, mxCOMPLEX);
  double* xr = mxGetPr(md);
  double* xi = mxGetPi(md);
  for(int i=0; i<m; i++) {
	xr[i] = real(cd(i));
	xi[i] = imag(cd(i));
  }
  return;
}

#endif
