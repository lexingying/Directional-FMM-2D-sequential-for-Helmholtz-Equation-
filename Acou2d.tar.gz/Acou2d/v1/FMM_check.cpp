#include "mex.h"
#include "mexaux.hpp"

using namespace std;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  //input
  Wave2d* ptr;  mex2cpp(prhs[0], ptr);
  CpxNumVec ds; mex2cpp(prhs[1], ds);
  CpxNumVec vs; mex2cpp(prhs[2], vs);
  int numchk; mex2cpp(prhs[3], numchk);
  vector<cpx> den(ds.m());  for(int i=0; i<den.size(); i++)    den[i] = ds(i);
  vector<cpx> val(vs.m());  for(int i=0; i<val.size(); i++)    val[i] = vs(i);
  
  //call eval
  double relerr;
  iC( ptr->check(den,val,numchk,relerr) );
  
  //output
  cpp2mex(relerr, plhs[0]);
  return;
}
