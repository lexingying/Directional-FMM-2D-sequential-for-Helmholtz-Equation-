function M = smat(chmat,k,eta,p1,p2)
  
  N = numel(p1);
  
  if(strcmp(chmat,'doub')==1)
    %------------------------------------
    %0. gaussian quad weights
    pres = [N 1:N-1];
    nxts = [2:N 1];
    
    o1 = [p1(end) p1(1:end-1)]; %the prev point
    o2 = [p2(end) p2(1:end-1)];
    q1 = [p1(2:end) p1(1)]; %the next point
    q2 = [p2(2:end) p2(1)];

    tmp = load('gau5');
    pos = tmp(:,1)';  wgt = tmp(:,2)';
    
    d1 = q1-p1;
    d2 = q2-p2;
    len = sqrt(d1.^2 + d2.^2);
    e1 = d2./len;
    e2 = -d1./len;
    
    D = numel(pos);
    y1 = (1-pos')*p1 + pos'*q1;
    y2 = (1-pos')*p2 + pos'*q2;
    hs = wgt'*len;
    e1 = ones(D,1)*e1;
    e2 = ones(D,1)*e2;
    
    y1 = y1(:)';    y2 = y2(:)';
    hs = hs(:)';
    e1 = e1(:)';    e2 = e2(:)';
    
    Q = numel(y1);
    r1 = p1'*ones(1,Q) - ones(N,1)*y1;
    r2 = p2'*ones(1,Q) - ones(N,1)*y2;
    n1 = ones(N,1) * e1;
    n2 = ones(N,1) * e2;
    r = sqrt(r1.^2 + r2.^2);
    rn = r1.*n1 + r2.*n2;
    clear r1 r2 n1 n2;
    
    M = i/4 * k * besselh(1,1,k*r) .* rn ./ r;
    M = M .* (ones(N,1)*hs);
    
    %2. interpolation matrix
    P = zeros(Q,N);
    for idx=1:N
      nxt = nxts(idx);
      tmp = (idx-1)*D + [1:D];
      P(tmp,idx) = 1-pos';
      P(tmp,nxt) = pos';
    end
    
    M = M*P; clear P;
    
    %3. H matrix
    fv = (q1-p1) + i*(q2-p2);    fv = fv./abs(fv);
    tv = (o1-p1) + i*(o2-p2);    tv = tv./abs(tv);
    ra = tv./fv;
    angle = atan2(imag(ra),real(ra));
    bad = find(angle<0);    angle(bad) = angle(bad)+2*pi;
    
    H = diag(angle/(2*pi));
    
    M = H + M;
  elseif(strcmp(chmat,'comb')==1)
    %------------------------------------
    %0. gaussian quad weights
    pres = [N 1:N-1];
    nxts = [2:N 1];
    
    o1 = [p1(end) p1(1:end-1)]; %the prev point
    o2 = [p2(end) p2(1:end-1)];
    q1 = [p1(2:end) p1(1)]; %the next point
    q2 = [p2(2:end) p2(1)];
    
    tmp = load('gau5');
    pos = tmp(:,1)';  wgt = tmp(:,2)';
    
    d1 = q1-p1;
    d2 = q2-p2; %q-p
    len = sqrt(d1.^2 + d2.^2);
    e1 = d2./len;
    e2 = -d1./len; %normal
    
    %--------
    D = numel(pos);
    y1 = (1-pos')*p1 + pos'*q1;
    y2 = (1-pos')*p2 + pos'*q2; %all quad points
    hs = wgt'*len;                           %quad weights
    e1 = ones(D,1)*e1;
    e2 = ones(D,1)*e2; %the normal at all quad points
    
    y1 = y1(:)';    y2 = y2(:)';
    hs = hs(:)';
    e1 = e1(:)';    e2 = e2(:)';
    
    Q = numel(y1);
    r1 = p1'*ones(1,Q) - ones(N,1)*y1;
    r2 = p2'*ones(1,Q) - ones(N,1)*y2;
    n1 = ones(N,1) * e1;
    n2 = ones(N,1) * e2;
    r = sqrt(r1.^2 + r2.^2);
    rn = r1.*n1 + r2.*n2;
    clear r1 r2 n1 n2;
    
    M0 = i/4 * k * besselh(1,1,k*r) .* rn ./ r;
    M0 = M0 .* (ones(N,1)*hs);
    
    M1 = i/4 * besselh(0,1,k*r);
    msk = ones(N,Q);
    pres = [N 1:N-1];
    nxts = [2:N 1];
    for idx=1:N
      tmp = (idx-1)*D + [1:D];
      msk(idx,tmp) = 0;
      pre = pres(idx); %the prev one
      tmp = (pre-1)*D + [1:D];
      msk(idx,tmp) = 0; %LEXING: GOT BURNED HERE
    end
    M1 = M1.*msk; %remove the log singularity
    M1 = M1 .* (ones(N,1)*hs);
    
    P = zeros(Q,N);
    for idx=1:N
      nxt = nxts(idx);
      tmp = (idx-1)*D + [1:D];
      P(tmp,idx) = 1-pos';
      P(tmp,nxt) = pos';
    end
    
    M0 = M0*P;
    
    M1 = M1*P;    %M = (M0-i*eta*M1) * P; clear M0 M1 P;
    
    %---------
    %1. log quadrature
    tmp = load('log5');
    pos = tmp(:,1)';    wgt = tmp(:,2)';
    D = numel(pos);
    
    M2 = zeros(N,N);
    pres = [N 1:N-1];
    nxts = [2:N 1];
    for idx=1:N
      %prev
      pre = pres(idx);
      nxt = nxts(idx);
      for neb=[pre nxt]
        x1 = p1(idx);      x2 = p2(idx);
        t1 = p1(neb);      t2 = p2(neb);
        d1 = t1-x1;      d2 = t2-x2;
        len = sqrt(d1.^2 + d2.^2);
        
        y1 = (1-pos)*x1 + pos*t1;
        y2 = (1-pos)*x2 + pos*t2;
        hs = wgt*len;
        r1 = x1-y1;        r2 = x2-y2;
        r = sqrt(r1.^2 + r2.^2);
        T = i/4 * besselh(0,1,k*r);
        T = T .* hs;
        
        P = zeros(D,2);
        P(:,1) = 1-pos';
        P(:,2) = pos';
        T = T*P;
        M2(idx,[idx,neb]) = M2(idx,[idx,neb]) + T;
      end
    end    %M = M - i*eta*M2;
    
    M = M0 - i*eta*(M1+M2);
    
    %3. H matrix
    fv = (q1-p1) + i*(q2-p2);    fv = fv./abs(fv);
    tv = (o1-p1) + i*(o2-p2);    tv = tv./abs(tv);
    ra = tv./fv;
    angle = atan2(imag(ra),real(ra));
    bad = find(angle<0);    angle(bad) = angle(bad)+2*pi;
    
    H = diag(angle/(2*pi));
    
    M = H + M;
  else
    %------------------------------------
    error('wrong');
  end
  
  