#ifndef _ACOU2D_HPP_
#define _ACOU2D_HPP_

#include "comobject.hpp"
#include "vec2t.hpp"
#include "numtns.hpp"
#include "offtns.hpp"
#include "kernel2d.hpp"
#include "wave2d.hpp"
#include "petscsnes.h"

using std::vector;
using std::pair;
using std::map;
using std::set;
using std::cerr;
using std::cout;
using std::ostream;
using std::istream;

//---------------------------------------------------------------------------
class Acou2d: public ComObject
{
public:
  //input
  vector<Point2> _vertvec;
  vector<Index2> _edgevec;
  Point2 _ctr;
  int _accu;
  Kernel2d _knlbie;//what bie kernel to use
  //local
  vector<double> _diavec; //diagonal (angle/2pi)
  vector<double> _lenvec; //length of each segment
  vector<Point2> _posvec; //pos used in fmm
  vector<Point2> _norvec; //nor used in fmm
  Wave2d _wave;
  map<int,DblNumMat> _gauwgts;
  map<int,DblNumMat> _logwgts;
public:
  Acou2d(const string& p);
  ~Acou2d();
  //
  int setup(vector<Point2>& vertvec, vector<Index2>& edgevec,
			Point2 ctr, int accu, Kernel2d knlbie);
  //
  int solve(vector<cpx>& rhs, vector<cpx>& den);
  int mmult(vector<cpx>& in, vector<cpx>& ot);
  //PETSC stuff
  static int mmultWrapper(Mat, Vec, Vec);
  //
  int eval(vector<Point2>& chk, vector<cpx>& den, vector<cpx>& val);//potential
};


#endif
