#include "acou2d.hpp"
#include "serialize.hpp"

using std::cerr;

//-----------------------------------
Acou2d::Acou2d(const string& p): ComObject(p), _wave(p+"_wave")
{
}

//-----------------------------------
Acou2d::~Acou2d()
{
}

//-----------------------------------
int Acou2d::setup(vector<Point2>& vertvec, vector<Index2>& edgevec,
		  Point2 ctr, int accu, Kernel2d knlbie)
{
  _vertvec = vertvec;
  _edgevec = edgevec;
  _ctr = ctr;
  _accu = accu;
  _knlbie = knlbie; cerr<<"type "<<_knlbie.type()<<endl;
  //1. compute _diavec
  vector<Index2> v2evec;
  v2evec.resize(_vertvec.size());
  for(int ei=0; ei<_edgevec.size(); ei++) {
    Index2 curedg = _edgevec[ei];
    int fv = curedg(0);
    int tv = curedg(1);
    v2evec[fv](1) = ei;
    v2evec[tv](0) = ei;
  }
  _diavec.resize(_vertvec.size());
  for(int vi=0; vi<_vertvec.size(); vi++) {
    int cvi = vi;
    int pvi = _edgevec[ v2evec[vi](0) ](0);
    int nvi = _edgevec[ v2evec[vi](1) ](1);
    Point2 difp = _vertvec[pvi] - _vertvec[cvi];
    Point2 difn = _vertvec[nvi] - _vertvec[cvi];
    cpx tv(difp(0),difp(1)); //to
    cpx fv(difn(0),difn(1)); //from
    cpx ra = tv/fv;
    double angle = atan2(imag(ra), real(ra));
    if(angle<0) angle = angle+2*M_PI;
    _diavec[vi] = angle / (2*M_PI);
  }
  //for(int vi=0; vi<_vertvec.size(); vi++)    cerr<<_diavec[vi]<<endl;
  _lenvec.resize(_edgevec.size());
  for(int ei=0; ei<_edgevec.size(); ei++) {
    Point2 pos0 = _vertvec[ _edgevec[ei](0) ];
    Point2 pos1 = _vertvec[ _edgevec[ei](1) ];
    _lenvec[ei] = (pos0-pos1).l2();
  }
  //2. load the quad weights
  vector<int> all(1,1);
  ifstream gin("gauwgts.bin");
  iC( deserialize(_gauwgts, gin, all) );
  cerr<<"gauwgts size "<<_gauwgts.size()<<endl;
  ifstream lin("logwgts.bin");
  iC( deserialize(_logwgts, lin, all) );
  cerr<<"logwgts size "<<_logwgts.size()<<endl;
  //
  return 0;
}

//-----------------------------------
int Acou2d::solve(vector<cpx>& rhs, vector<cpx>& den)
{
  //1. create fmm
  DblNumMat& gauwgt = _gauwgts[5];
  DblNumMat& logwgt = _logwgts[5];
  int NE = _edgevec.size();
  int NV = _vertvec.size();
  //
  //2. setup
  // sample points to get the pvec nvec
  int numgau = gauwgt.m();
  _posvec.clear();
  _norvec.clear();
  for(int ei=0; ei<_edgevec.size(); ei++) {
    Point2 pos0 = _vertvec[ _edgevec[ei](0) ];
    Point2 pos1 = _vertvec[ _edgevec[ei](1) ];
    Point2 dif = pos1-pos0;
    double len = dif.l2();
    Point2 nor( dif(1)/len, -dif(0)/len );
    for(int gi=0; gi<numgau; gi++) {
      double loc = gauwgt(gi,0);
      double wgt = gauwgt(gi,1);
      _posvec.push_back( (1-loc)*pos0 + loc*pos1 );
      _norvec.push_back( nor );
    }
  }
  for(int vi=0; vi<_vertvec.size(); vi++) {
    _posvec.push_back( _vertvec[vi] );
    _norvec.push_back( _vertvec[vi] ); //dummy
  }
  iA( _posvec.size()==NE*numgau+NV );
  iC( _wave.setup(_posvec, _norvec, _ctr, _accu, _knlbie) );
  //3. call gmres
  double tol;
  switch(_accu) {
  case 1:
    tol = 1e-3; break;
  case 2:
    tol = 1e-5; break;
  case 3:
    tol = 1e-7; break;
  }
  cerr<<"tol "<<tol<<endl;
  //
  int N = NV;
  Mat mat;  iC( MatCreateShell(PETSC_COMM_SELF, N, N, N, N, (void*)this, &mat) );
  iC( MatShellSetOperation(mat, MATOP_MULT, (void(*)(void))Acou2d::mmultWrapper) );
  //
  KSP ksp;  iC( KSPCreate(PETSC_COMM_SELF, &ksp) );
  iC( KSPSetOperators(ksp, mat, mat, DIFFERENT_NONZERO_PATTERN) );
  iC( KSPSetType(ksp, KSPGMRES) );
  iC( KSPSetTolerances(ksp, tol, PETSC_DEFAULT,PETSC_DEFAULT,PETSC_DEFAULT) );
  iC( KSPGMRESSetRestart(ksp, 100) );  iC( KSPSetFromOptions(ksp) );
  //allocate data
  Vec r;  iC( VecCreateSeqWithArray(PETSC_COMM_SELF, N, &(rhs[0]), &r) );
  Vec d;  iC( VecCreateSeq(PETSC_COMM_SELF, N, &d) );
  iC( KSPSolve(ksp, r, d) );
  int nit;  iC( KSPGetIterationNumber(ksp,&nit) );  cerr<<"nit "<<nit<<endl;
  //
  den.resize(N);
  cpx* darr;  iC( VecGetArray(d, &darr) );
  for(int k=0; k<N; k++)    den[k] = darr[k];
  iC( VecRestoreArray(d, &darr) );
  //
  iC( VecDestroy(r) ); r=NULL;
  iC( VecDestroy(d) ); d=NULL;
  iC( KSPDestroy(ksp) ); ksp=NULL;
  iC( MatDestroy(mat) ); mat=NULL;
  return 0;
}

//-----------------------------------
int Acou2d::mmult(vector<cpx>& in, vector<cpx>& ot)
{
  DblNumMat& gauwgt = _gauwgts[5];
  DblNumMat& logwgt = _logwgts[5];
  int numgau = gauwgt.m();
  int numlog = logwgt.m();
  int NE = _edgevec.size();
  int NV = _vertvec.size();
  //-------------
  if(       _knlbie.type()==KNL_HELM_DOUB) {
    //-----------------------------
    //1.scale wgt TODO (gaussian quad)
    vector<cpx> tmp(NE*numgau + NV, cpx(0,0)); //ALL ZERO
    int cnt = 0;
    for(int ei=0; ei<_edgevec.size(); ei++) {
      double len = _lenvec[ei];
      cpx den0 = in[ _edgevec[ei](0) ];
      cpx den1 = in[ _edgevec[ei](1) ];
      for(int gi=0; gi<numgau; gi++) {
	double loc = gauwgt(gi,0);
	double wgt = gauwgt(gi,1);
	tmp[cnt] = ((1-loc)*den0 + loc*den1) * (len*wgt);
	cnt++;
      }
    }
    iA( cnt==NE*numgau );
    //2. call FMM
    vector<cpx> aux(NE*numgau + NV, cpx(0,0));
    time_t t0, t1;
    t0 = time(0);
    iC( _wave.eval(tmp,aux) );
    t1 = time(0);  cout<<"wave eval used "<<difftime(t1,t0)<<"secs "<<endl;
    //3. angle
    for(int vi=0; vi<_vertvec.size(); vi++) {
      ot[vi] = _diavec[vi]*in[vi] + aux[cnt];
      cnt++;
    }
    iA( cnt==NE*numgau+NV );
    //
  } else if(_knlbie.type()==KNL_HELM_COMB) {
    //-----------------------------
    //1. scale wgt (gaussian)
    vector<cpx> tmp(NE*numgau + NV, cpx(0,0));
    int cnt = 0;
    for(int ei=0; ei<_edgevec.size(); ei++) {
      double len = _lenvec[ei]; //length
      cpx den0 = in[ _edgevec[ei](0) ];
      cpx den1 = in[ _edgevec[ei](1) ];
      for(int gi=0; gi<numgau; gi++) {
	double loc = gauwgt(gi,0);
	double wgt = gauwgt(gi,1);
	tmp[cnt] = ((1-loc)*den0 + loc*den1) * (len*wgt);
	cnt++;
      }
    }
    iA( cnt==NE*numgau );
    //2. call fmm
    vector<cpx> aux(NE*numgau + NV, cpx(0,0));
    time_t t0, t1;
    t0 = time(0);
    iC( _wave.eval(tmp,aux) );
    t1 = time(0);  cout<<"wave eval used "<<difftime(t1,t0)<<"secs "<<endl;
    //3. angle
    for(int vi=0; vi<_vertvec.size(); vi++) {
      ot[vi] = _diavec[vi]*in[vi] + aux[cnt];
      cnt++;
    }
    iA( cnt==NE*numgau+NV );
    //3. remove nearby from ot
    t0 = time(0);
    for(int ei=0; ei<_edgevec.size(); ei++) {
      //
      DblNumMat srcpos(2,numgau,false,(double*)(&_posvec[ei*numgau]));
      DblNumMat srcnor(2,numgau,false,(double*)(&_norvec[ei*numgau]));
      //
      DblNumMat trgpos(2,2);
      Point2 pos0 = _vertvec[ _edgevec[ei](0) ];
      Point2 pos1 = _vertvec[ _edgevec[ei](1) ];
      trgpos(0,0) = pos0(0);      trgpos(1,0) = pos0(1);
      trgpos(0,1) = pos1(0);      trgpos(1,1) = pos1(1);
      //
      CpxNumVec srcden(numgau,false,(cpx*)(&tmp[ei*numgau]));
      //
      CpxNumVec trgval(2);
      //
      CpxNumMat mat;      iC( _knlbie.kernel(trgpos, srcpos, srcnor, mat) );
      iC( zgemv(1.0, mat, srcden, 0.0, trgval) );
      //
      ot[ _edgevec[ei](0) ] -= trgval(0);
      ot[ _edgevec[ei](1) ] -= trgval(1);
    }
    //4. visit edge and add log correction
    for(int ei=0; ei<_edgevec.size(); ei++) {
      Point2 pos0 = _vertvec[ _edgevec[ei](0) ];
      Point2 pos1 = _vertvec[ _edgevec[ei](1) ];
      Point2 dif = pos1-pos0;
      double len = dif.l2();
      Point2 nor( dif(1)/len, -dif(0)/len );
      cpx den0 = in[ _edgevec[ei](0) ];
      cpx den1 = in[ _edgevec[ei](1) ];
      //
      DblNumMat srcpos(2,numlog);
      DblNumMat srcnor(2,numlog);
      DblNumMat trgpos(2,1);
      CpxNumVec srcden(numlog);
      CpxNumVec trgval(1);
      CpxNumMat mat;
      //left
      for(int li=0; li<numlog; li++) {
	double loc = logwgt(li,0);
	double wgt = logwgt(li,1);
	Point2 pos = (1-loc)*pos0 + loc*pos1;
	srcpos(0,li) = pos(0);	srcpos(1,li) = pos(1);
	srcnor(0,li) = nor(0);	srcnor(1,li) = nor(1);
	srcden(li) = ( (1-loc)*den0 + loc*den1 ) * (len*wgt);
      }
      trgpos(0,0) = pos0(0);	trgpos(1,0) = pos0(1);
      iC( _knlbie.kernel(trgpos,srcpos,srcnor,mat) );
      iC( zgemv(1.0, mat, srcden, 0.0, trgval) );
      ot[ _edgevec[ei](0) ] += trgval(0);
      //right
      for(int li=0; li<numlog; li++) {
	double loc = logwgt(li,0);
	double wgt = logwgt(li,1);
	Point2 pos = (1-loc)*pos1 + loc*pos0;
	srcpos(0,li) = pos(0);	srcpos(1,li) = pos(1);
	srcnor(0,li) = nor(0);	srcnor(1,li) = nor(1);
	srcden(li) = ( (1-loc)*den1 + loc*den0 ) * (len*wgt);
      }
      trgpos(0,0) = pos1(0);	trgpos(1,0) = pos1(1);
      iC( _knlbie.kernel(trgpos,srcpos,srcnor,mat) );
      iC( zgemv(1.0, mat, srcden, 0.0, trgval) );
      ot[ _edgevec[ei](1) ] += trgval(0);
    }
    t1 = time(0);  cout<<"correction used "<<difftime(t1,t0)<<"secs "<<endl;
  }
  return 0;
}

//-----------------------------------
int Acou2d::mmultWrapper(Mat M, Vec in, Vec ot)
{
  Acou2d* ptr = NULL;
  iC( MatShellGetContext(M, (void**)&ptr) );
  int N = ptr->_vertvec.size();
  //
  vector<cpx> aa(N);
  cpx* inarr;  iC( VecGetArray(in, &inarr) );
  for(int k=0; k<N; k++)    aa[k] = inarr[k];
  iC( VecRestoreArray(in, &inarr) );
  //
  vector<cpx> bb(N,cpx(0,0));
  iC( ptr->mmult(aa, bb) );
  //
  cpx* otarr;  iC( VecGetArray(ot, &otarr) );
  for(int k=0; k<N; k++)    otarr[k] = bb[k];
  iC( VecRestoreArray(ot, &otarr) );
  //
  return 0;
}

//-----------------------------------
int Acou2d::eval(vector<Point2>& chk, vector<cpx>& den, vector<cpx>& val)
{
  DblNumMat& gauwgt = _gauwgts[5];
  //
  int numgau = gauwgt.m();
  int NE = _edgevec.size();
  _posvec.clear();
  _norvec.clear();
  vector<cpx> denvec;
  vector<cpx> valvec;
  for(int ei=0; ei<_edgevec.size(); ei++) {
    Point2 pos0 = _vertvec[ _edgevec[ei](0) ];
    Point2 pos1 = _vertvec[ _edgevec[ei](1) ];
    Point2 dif = pos1-pos0;
    double len = dif.l2();
    Point2 nor( dif(1)/len, -dif(0)/len );
    //
    cpx den0 = den[ _edgevec[ei](0) ];
    cpx den1 = den[ _edgevec[ei](1) ];
    //
    for(int gi=0; gi<numgau; gi++) {
      double loc = gauwgt(gi,0);
      double wgt = gauwgt(gi,1);
      _posvec.push_back( (1-loc)*pos0 + loc*pos1 );
      _norvec.push_back( nor );
      denvec.push_back( ((1-loc)*den0 + loc*den1)*(len*wgt) );
    }
  }
  for(int ci=0; ci<chk.size(); ci++) {
    _posvec.push_back( chk[ci] );
    _norvec.push_back( chk[ci] );
    denvec.push_back( cpx(0,0) );
  }
  iC( _wave.setup(_posvec,_norvec, _ctr, _accu, _knlbie) );
  valvec.resize(denvec.size(), cpx(0,0));
  iC( _wave.eval(denvec, valvec) );
  val.resize(chk.size());
  for(int ci=0; ci<chk.size(); ci++) {
    val[ci] = valvec[ numgau*NE + ci ];
  }
  return 0;
}


