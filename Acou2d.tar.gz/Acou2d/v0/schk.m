function [t1,t2,msk] = schk(chchk,chgeo,R)
  if(    strcmp(chchk,'grid')==1)
    %--------------------
    step = 1/8;
    if(strcmp(chgeo,'circ')==1)
      BD = 1.25;
      [t1,t2] = ndgrid([-BD*R:step:BD*R], [-BD*R:step:BD*R]);
      msk = ((t1/R).^2 + (t2/R).^2 >= 1.1^2);
    elseif(strcmp(chgeo,'kite')==1)
      BD = 1.25;
      [t1,t2] = ndgrid([-BD*R:step:BD*R], [-BD*R:step:BD*R]);
      CF = 0.875*R;
      msk = (4*((t1/CF)+(t2/CF).^2).^2 + (t2/CF).^2 >= 1.1^2 );
    elseif(strcmp(chgeo,'sqre')==1)
      BD = 1.75;
      [t1,t2] = ndgrid([-BD*R:step:BD*R], [-BD*R:step:BD*R]);
      msk = (max(abs(t1),abs(t2)) > 1.1*R);
    else
      error('wrong');
    end
  elseif(strcmp(chchk,'curv')==1)
    %--------------------
    BD = 1.2;
    NC = R*16;
    theta = [0:NC-1]/NC * 2*pi;
    if(strcmp(chgeo,'circ')==1)
      A = 1*R;    B = 1*R;
      A = A*BD;      B = B*BD;
      t1 = A*cos(theta);      t2 = B*sin(theta);
      msk = ones(size(t1));
    elseif(strcmp(chgeo,'kite')==1)
      CF = 0.875*R;
      CF = 2*CF;
      t1 = CF * (cos(theta)/2 - sin(theta).^2);      t2 = CF * (sin(theta));
      msk = ones(size(t1));
    elseif(strcmp(chgeo,'dipp')==1)
      A = 1*R;    B = 1*R;
      A = A*BD;      B = B*BD;
      t1 = A*cos(theta);      t2 = B*sin(theta);
      msk = ones(size(t1));
    elseif(strcmp(chgeo,'sqre')==1)
      L = NC/4;
      gd = [0:L-1]/L;
      t1 = [gd; zeros(1,L)];
      t2 = [ones(1,L); gd];
      t3 = [1-gd; ones(1,L)];
      t4 = [zeros(1,L); 1-gd];
      tt = [t1 t2 t3 t4];
      tt = (tt*2-1)*R * BD;
      t1 = tt(1,:);
      t2 = tt(2,:);
      msk = ones(size(t1));
    else
      error('wrong');
    end
  else
    %--------------------
    error('wrong');
  end
  