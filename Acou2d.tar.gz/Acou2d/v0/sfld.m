function f = sfld(chfld,k,p1,p2)
  N = numel(p1);
  if(    strcmp(chfld,'xdir')==1)
    %----------
    d1 = 1; d2 = 0;
    f = exp(i*k*(p1*d1 + p2*d2));%f = ones(N,1);
  elseif(strcmp(chfld,'oblq')==1)
    %----------
    d1 = 1; d2 = 1;
    len = sqrt(d1^2+d2^2);
    d1 = d1/len;    d2 = d2/len;
    f = exp(i*k*(p1*d1 + p2*d2));%f = ones(N,1);
  elseif(strcmp(chfld,'rand')==1)
    %----------
    f = randn(1,N);
  else
    %----------
    error('wrong');
  end
  