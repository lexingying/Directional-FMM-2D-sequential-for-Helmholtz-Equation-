%---------------------------------
if(1)
  ns = [4:16];
  gauwgts = cell(length(ns),2);
  for ni=1:numel(ns)
    n = ns(ni);
    if(1)
      beta = 0.5./sqrt(1-(2*(1:n-1)).^(-2));
      T = diag(beta,1) + diag(beta,-1);
      [V,D] = eig(T);
      x = diag(D);
      [x,i] = sort(x);
      w = 2*V(1,i).^2; w = w';
      x = (x+1)/2;
      w = w/2;
    end
    gauwgts{ni,1} = n;
    gauwgts{ni,2} = [x w];
  end
  
  binstr = sprintf('gauwgts.bin');
  fid = fopen(binstr,'w');
  string = {'map', ...
            {'int'}, ...
            {'DblNumMat'}, ...
           };
  serialize(fid, gauwgts, string);
  fclose(fid);
  
  fid = fopen(binstr,'r');
  new = deserialize(fid,string);
  fclose(fid);
end

%---------------------------------
if(1)
  ns = [5 10];
  logwgts = cell(length(ns),2);
  for ni=1:numel(ns)
    n = ns(ni);
    fname = sprintf('log%d',n);
    tmp = load(fname);
    logwgts{ni,1} = n;
    logwgts{ni,2} = tmp;
  end
  
  binstr = sprintf('logwgts.bin');
  fid = fopen(binstr,'w');
  string = {'map', ...
            {'int'}, ...
            {'DblNumMat'}, ...
           };
  serialize(fid, logwgts, string);
  fclose(fid);
  
  fid = fopen(binstr,'r');
  new = deserialize(fid,string);
  fclose(fid);
end


%---------------------------------
if(0)
  n = 6;
  beta = 0.5./sqrt(1-(2*(1:n-1)).^(-2));
  T = diag(beta,1) + diag(beta,-1);
  [V,D] = eig(T);
  x = diag(D);
  [x,i] = sort(x);
  w = 2*V(1,i).^2;
end

