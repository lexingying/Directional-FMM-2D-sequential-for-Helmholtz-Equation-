%------------------------------------------
if(1)
  k = 2*pi;
  
  chgeo = 'dipp';
  chfld = 'xdir';
  chchk = 'curv';
  
  NPW = 16;
  h = 1/NPW;
  %Ks = [1024 2048 4096 8192];
  Ks = [16 128 256 512];
  for idx=1:numel(Ks)
    K = Ks(idx);
    R = K/2;
    [p1,p2] = sgeo(chgeo,R,h);
    b = -sfld(chfld,k,p1,p2);
    [c1,c2,msk] = schk(chchk,chgeo,R);
    
    N = numel(p1);
    C = numel(c1);
    
    %vert
    tmp = cell(N,1);
    for idx=1:N
      tmp{idx} = [p1(idx) p2(idx)];
    end
    binstr = sprintf('%s_%d_%d_vert',chgeo,K,NPW);
    fid = fopen(binstr,'w');
    string = {'vector',{'Point2'}};
    serialize(fid, tmp, string);
    fclose(fid);
    
    %edge
    now = [0:N-1];
    nxt = [1:N-1 0];
    tmp = cell(N,1);
    for idx=1:N
      tmp{idx} = [now(idx) nxt(idx)];
    end
    binstr = sprintf('%s_%d_%d_edge',chgeo,K,NPW);
    fid = fopen(binstr,'w');
    string = {'vector',{'Index2'}};
    serialize(fid, tmp, string);
    fclose(fid);
    
    %boundary cond
    tmp = cell(N,1);
    for idx=1:N
      tmp{idx} = b(idx);
    end
    binstr = sprintf('%s_%d_%d_bcn',chgeo,K,NPW);
    fid = fopen(binstr,'w');
    string = {'vector',{'cpx'}};
    serialize(fid, tmp, string);
    fclose(fid);
    
    %check
    tmp = cell(C,1);
    for idx=1:C
      tmp{idx} = [c1(idx),c2(idx)];
    end
    binstr = sprintf('%s_%d_%d_chk',chgeo,K,NPW);
    fid = fopen(binstr,'w');
    string = {'vector',{'Point2'}};
    serialize(fid, tmp, string);
    fclose(fid);
  end
end



%------------------------------------------
if(0)
  binstr = sprintf('%s_%d_%d_val',chgeo,K,NPW);
  fid = fopen(binstr,'r');
  %string = {'vector',{'cpx'}};
  string = {'CpxNumVec'};
  val = deserialize(fid, string);
  fclose(fid);
end

if(0)
  binstr = 'kite_1024_16_val2';
  fid = fopen(binstr,'r');
  %string = {'vector',{'cpx'}};
  string = {'CpxNumVec'};
  val = deserialize(fid, string);
  fclose(fid);
  P = sqrt(numel(val));
  val = reshape(val, [P,P]);
  val = val.';
  imagesc(real(val)); colorbar;
end
