function E = sevl(chmat,k,eta,p1,p2,c1,c2);
  N = numel(p1);
  C = numel(c1);
  
  pres = [N 1:N-1];
  nxts = [2:N 1];
  
  o1 = [p1(end) p1(1:end-1)]; %the prev point
  o2 = [p2(end) p2(1:end-1)];
  q1 = [p1(2:end) p1(1)]; %the next point
  q2 = [p2(2:end) p2(1)];
  
  if(strcmp(chmat,'doub')==1)
    %------------------------------------
    tmp = load('gau5');
    pos = tmp(:,1)';  wgt = tmp(:,2)';
    
    d1 = q1-p1;
    d2 = q2-p2;
    len = sqrt(d1.^2 + d2.^2);
    e1 = d2./len;
    e2 = -d1./len;
    
    D = numel(pos);
    y1 = (1-pos')*p1 + pos'*q1;
    y2 = (1-pos')*p2 + pos'*q2;
    hs = wgt'*len;
    e1 = ones(D,1)*e1;
    e2 = ones(D,1)*e2;    
    
    y1 = y1(:)';    y2 = y2(:)';
    hs = hs(:)';
    e1 = e1(:)';    e2 = e2(:)';
    
    Q = numel(y1);
    r1 = c1'*ones(1,Q) - ones(C,1)*y1;
    r2 = c2'*ones(1,Q) - ones(C,1)*y2;
    n1 = ones(C,1) * e1;
    n2 = ones(C,1) * e2;
    r = sqrt(r1.^2 + r2.^2);
    rn = r1.*n1 + r2.*n2;
    
    M = i/4 * k * besselh(1,1,k*r) .* rn ./ r;
    M = M .* (ones(C,1)*hs);
    
    %2. interpolation matrix
    P = zeros(Q,N);
    kns = [2:N 1];
    for idx=1:N
      nxt = nxts(idx);
      tmp = (idx-1)*D + [1:D];
      P(tmp,idx) = 1-pos';
      P(tmp,nxt) = pos';
    end
    
    E = M*P; clear P;
  elseif(strcmp(chmat,'comb')==1)
    %------------------------------------
    tmp = load('gau5');
    pos = tmp(:,1)';  wgt = tmp(:,2)';
    
    d1 = q1-p1;
    d2 = q2-p2;
    len = sqrt(d1.^2 + d2.^2);
    e1 = d2./len;
    e2 = -d1./len;
    
    D = numel(pos);
    y1 = (1-pos')*p1 + pos'*q1;
    y2 = (1-pos')*p2 + pos'*q2;
    hs = wgt'*len;
    e1 = ones(D,1)*e1;
    e2 = ones(D,1)*e2;    
    
    y1 = y1(:)';    y2 = y2(:)';
    hs = hs(:)';
    e1 = e1(:)';    e2 = e2(:)';
    
    Q = numel(y1);
    r1 = c1'*ones(1,Q) - ones(C,1)*y1;
    r2 = c2'*ones(1,Q) - ones(C,1)*y2;
    n1 = ones(C,1) * e1;
    n2 = ones(C,1) * e2;
    r = sqrt(r1.^2 + r2.^2);
    rn = r1.*n1 + r2.*n2;
    
    M = i/4*k*besselh(1,1,k*r).*rn./r - i*eta * i/4*besselh(0,1,k*r);
    M = M .* (ones(C,1)*hs);
    
    %2. interpolation matrix
    P = zeros(Q,N);
    kns = [2:N 1];
    for idx=1:N
      nxt = nxts(idx);
      tmp = (idx-1)*D + [1:D];
      P(tmp,idx) = 1-pos';
      P(tmp,nxt) = pos';
    end
    
    E = M*P; clear P;
  else
    %------------------------------------
    error('wrong');
  end
  