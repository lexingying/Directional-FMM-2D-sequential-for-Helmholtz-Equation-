#include "acou2d.hpp"
#include "serialize.hpp"

using namespace std;

int optionsCreate(int argc, char** argv, map<string,string>& options)
{
  options.clear();
  for(int k=1; k<argc; k=k+2) {
    options[ string(argv[k]) ] = string(argv[k+1]);
  }
  return 0;
}

int main(int argc, char** argv)
{
  PetscInitialize(&argc,&argv,NULL,NULL);
  //
  clock_t ck0, ck1;
  time_t t0, t1;
  srand48(time(NULL));
  map<string,string> opts;
  optionsCreate(argc, argv, opts);
  //1. read stuff
  map<string,string>::iterator mi;
  vector<int> all(1,1);
  //
  mi = opts.find("-vertfile");  assert(mi!=opts.end());
  char vertname[100];  {istringstream ss((*mi).second);  ss>>vertname;}
  vector<Point2> vertvec;  {ifstream fin(vertname);  iC( deserialize(vertvec, fin, all) );  }
  //
  mi = opts.find("-edgefile");  assert(mi!=opts.end());
  char edgename[100];  {istringstream ss((*mi).second);  ss>>edgename;}
  vector<Index2> edgevec;  {ifstream fin(edgename);  iC( deserialize(edgevec, fin, all) );  }
  //
  int N = vertvec.size();
  //
  Point2 ctr(0,0);
  //
  mi = opts.find("-accu");  assert(mi!=opts.end());
  int accu;  {istringstream ss((*mi).second);  ss>>accu;}  iA( accu>=1 && accu<=3 );
  mi = opts.find("-kt");  assert(mi!=opts.end());
  int kt;  {istringstream ss((*mi).second);  ss>>kt;}  iA( kt==KNL_HELM_DOUB || kt==KNL_HELM_COMB);
  Kernel2d knlbie(kt);
  //2. scattering
  Acou2d acou("acou2d");
  iC( acou.setup(vertvec, edgevec, ctr, accu, knlbie) );
  //
  //load den
  mi = opts.find("-denfile");  assert(mi!=opts.end());
  char denname[100]; {istringstream ss((*mi).second);  ss>>denname;}
  vector<cpx> denvec;  {ifstream fin(denname);    iC( deserialize(denvec, fin, all) );  }
  //
  mi = opts.find("-chkfile");  assert(mi!=opts.end());
  char chkname[100]; {istringstream ss((*mi).second);  ss>>chkname;}
  vector<Point2> chkvec;  {ifstream fin(chkname);    iC( deserialize(chkvec, fin, all) );  }
  int C = chkvec.size();
  //
  vector<cpx> valvec(C, cpx(0,0));
  iC( acou.eval(chkvec, denvec, valvec) );
  //
  mi = opts.find("-valfile");  assert(mi!=opts.end());
  char valname[100]; {istringstream ss((*mi).second);  ss>>valname;}
  {ofstream fot(valname);  iC( serialize(valvec, fot, all) ); }
  //
  PetscFinalize();
  return 0;
}





