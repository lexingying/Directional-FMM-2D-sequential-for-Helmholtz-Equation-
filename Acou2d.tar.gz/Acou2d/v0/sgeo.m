function [p1,p2] = sgeo(chgeo,R,h)
  if(strcmp(chgeo,'circ')==1)
    tmp = 2*pi*R;    N = ceil(tmp/h);
    theta = [0:N-1]/N * 2*pi;
    A = (1-1e-10)*R;
    B = (1-1e-10)*R;
    p1 = A*cos(theta);
    p2 = B*sin(theta);
  elseif(strcmp(chgeo,'kite')==1)
    tmp = 2*pi*R;    N = ceil(tmp/h);
    theta = [0:N-1]/N * 2*pi;
    CF = 0.875*R;
    p1 = CF * (cos(theta)/2 - sin(theta).^2);
    p2 = CF * (sin(theta));
  elseif(strcmp(chgeo,'dipp')==1)
    tmp = 2*pi*R;    N = ceil(tmp/h);
    ts = [0:N-1]/N * 2*pi;
    t0 = 3/4*pi;
    A = (1-1e-10)*R;
    rs = A*(1-0.2*exp(-128*(ts-t0).^2));
    p1 = rs.*cos(ts);
    p2 = rs.*sin(ts);
  elseif(strcmp(chgeo,'sqre')==1)
    %tmp = 8*R;    N = ceil(tmp/h);
    %L = N/4;
    %tmp = [0:L-1]/L;
    %gd = (1-cos(pi*tmp))/2;
    D = 2*R;
    NPW = 1/h;
    tmp = [0:NPW*4-1]/(NPW*4);
    gd = (1-cos(pi*tmp));
    lf = gd(1:end/2);
    rt = gd((end/2+1):end);
    gd = [lf, 1 + [0:(D-2)/h-1]*h, D-2+rt];
    oo = ones(1,numel(gd));
    
    t1 = [gd; 0*oo];
    t2 = [2*R*oo; gd];
    t3 = [2*R-gd; 2*R*oo];
    t4 = [0*oo; 2*R-gd];
    tt = [t1 t2 t3 t4];
    tt = tt - R;
    p1 = tt(1,:);
    p2 = tt(2,:);
  else
    error('wrong');
  end
  