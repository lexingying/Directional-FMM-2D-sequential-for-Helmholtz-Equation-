if(1)
  chgeo = 'circ';
  K = 2048;
  NPW = 16;
  binstr = sprintf('%s_%d_%d_val',chgeo,K,NPW);
  fid = fopen(binstr,'r');
  %string = {'vector',{'cpx'}};
  string = {'CpxNumVec'};
  val = deserialize(fid, string);
  fclose(fid);
end