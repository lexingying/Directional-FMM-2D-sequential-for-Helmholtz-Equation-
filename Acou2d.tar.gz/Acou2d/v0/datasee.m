if(1)
  close all;
  
  k = 2*pi;
  eta = pi;
  
  chgeo = 'circ';
  chmat = 'comb';
  chfld = 'xdir';
  chchk = 'curv';
  chslv = 'drct';
  
  K = 16;
  R = K/2;
  NPW = 16;
  h = 1/NPW;
  
  [p1,p2] = sgeo(chgeo,R,h);
  M = smat(chmat,k,eta,p1,p2);
  fld = sfld(chfld,k,p1,p2);
  rhs = -fld.';
  
  if(    strcmp(chslv,'drct')==1)
    den = M \ rhs;
  elseif(strcmp(chslv,'gmrs')==1)
    [den,flag,relres,iter,resvec] = gmres(M,rhs,80,1e-6,50);
  elseif(strcmp(chslv,'bicg')==1)
    [den,flag,relres,iter,resvec] = bicg(M,rhs,1e-6,1000);
  else
    error('wrong');
  end
  
  [t1,t2,msk] = schk(chchk,chgeo,R);
  gud = find(msk==1);  bad = find(msk==0);
  c1 = t1(gud); c2 = t2(gud); c1 = c1(:).';c2 = c2(:).';
  
  E = sevl(chmat,k,eta, p1,p2, c1,c2);
  fff = E*den;
  scf = zeros(size(t1));
  scf(gud) = fff;
end
