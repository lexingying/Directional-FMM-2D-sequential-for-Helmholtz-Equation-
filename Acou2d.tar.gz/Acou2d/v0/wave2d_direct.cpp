#include "wave2d.hpp"
#include "serialize.hpp"

//---------------------------------------------------------------------
int Wave2d::setup_direct(vector<Point2>& posvec, vector<Point2>& norvec,
			 Point2 ctr, int accu, Kernel2d knlbie)
{
  _self = this;
  _posvec = posvec;
  _norvec = norvec;
  _ctr = ctr;
  _accu = accu;
  _knlbie = knlbie;
  //
  iA(_knlbie.type()==KNL_HELM_SING ||
     _knlbie.type()==KNL_HELM_DOUB ||
     _knlbie.type()==KNL_HELM_COMB);
  //setup matrix
  int N = _posvec.size();
  DblNumMat trgpos(2,N);
  DblNumMat srcpos(2,N);
  DblNumMat srcnor(2,N);
  for(int k=0; k<N; k++) {
    trgpos(0,k) = _posvec[k](0);    trgpos(1,k) = _posvec[k](1);
    srcpos(0,k) = _posvec[k](0);    srcpos(1,k) = _posvec[k](1);
    srcnor(0,k) = _norvec[k](0);    srcnor(1,k) = _norvec[k](1);
  }
  _direct.resize(N,N);
  iC( _knlbie.kernel(trgpos, srcpos, srcnor, _direct) );
  // dump
  ofstream fot("direct");
  vector<int> all(1,1);
  iC( serialize(_direct, fot, all) );
  return 0;
}


//---------------------------------------------------------------------
int Wave2d::eval_direct(vector<cpx>& den, vector<cpx>& val)
{
  int N = _posvec.size();
  CpxNumVec d(N,false,&(den[0]));
  CpxNumVec v(N,false,&(val[0]));
  iC( zgemv(1.0, _direct, d, 0.0, v) );
  return 0;
}
